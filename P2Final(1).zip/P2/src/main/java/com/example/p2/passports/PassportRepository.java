package com.example.p2.passports;

import org.springframework.data.repository.CrudRepository;

import java.sql.ResultSet;
import java.util.Map;

public interface PassportRepository extends
        CrudRepository<Passport, Integer> {

}
