package com.example.p2.shippingAddresses;
import com.example.p2.users.User;
import com.example.p2.passports.Passport;
import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.*;

@Entity
@Table (name = "shipping_addresses_new")
public class ShippingAddress {
    @Id
    private Integer aId;
    private String address;
    @OneToOne
    @JoinColumn(name = "passport_number")
    private Passport passportNumber;
    @ManyToOne
    @JoinColumn(name = "u_id")
    private User uId;


    public Integer getaId() {
        return aId;
    }

    public void setaId(Integer aId) {

        this.aId = aId;
    }


    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public User getuId() {
        return uId;
    }

    public void setuId(User uId) {
        this.uId = uId;
    }

    public Passport getPassportNumber() {
        return passportNumber;
    }

    public void setPassportNumber(Passport passportNumber) {
        this.passportNumber = passportNumber;
    }

}
