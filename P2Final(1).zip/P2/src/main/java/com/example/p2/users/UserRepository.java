package com.example.p2.users;
import org.springframework.data.repository.CrudRepository;

public interface UserRepository extends
        CrudRepository<User, Integer> {
}
