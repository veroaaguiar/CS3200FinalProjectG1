package com.example.p2.shippingAddresses;

import com.example.p2.passports.Passport;
import com.example.p2.users.User;
import com.example.p2.users.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@RestController
@CrossOrigin(origins = "*")
public class ShippingAddressDAO {
    @Autowired
    ShippingAddressRepository shippingAddressRepository;
    UserRepository userRepository;

    @PostMapping("/api/shippingAddresses")
    public ShippingAddress createShippingAddress(@RequestBody ShippingAddress shippingAddress) {
        return shippingAddressRepository.save(shippingAddress);
    }

    @GetMapping("/api/shippingAddresses")
    public List<ShippingAddress> findAllShippingAddresses () {
        return (List<ShippingAddress>) shippingAddressRepository.findAll();
    }
    @GetMapping("/api/shippingAddresses/{aId}")
    public ShippingAddress findShippingAddressById(@PathVariable("aId") Integer aId) {
        return shippingAddressRepository.findById(aId).get();
    }


    @PutMapping("/api/shippingAddresses/{aId}")
    public ShippingAddress updateShippingAddress(
            @PathVariable("aId") Integer aId,
            @RequestBody ShippingAddress shippingAddressUpdates) {
        ShippingAddress shippingAddress = shippingAddressRepository.findById(aId).get();
        shippingAddress.setaId(shippingAddressUpdates.getaId());
        shippingAddress.setAddress(shippingAddressUpdates.getAddress());
        shippingAddress.setuId(shippingAddressUpdates.getuId());
        shippingAddress.setPassportNumber(shippingAddressUpdates.getPassportNumber());
        return shippingAddressRepository.save(shippingAddress);
    }

    @DeleteMapping("/api/shippingAddresses/{aId}")
    public void deleteShippingAddress(
            @PathVariable("aId") Integer aId) {
        shippingAddressRepository.deleteById(aId);
    }

//    @GetMapping("/api/users/{uId}/shippingAddresses")
//    public List<ShippingAddress> findAddressesByUser(
//            @PathVariable("uId")
//                    Integer uId) {
//        return userRepository
//                .findById(uId).get()
//                .getAddresses();
//    }

}
