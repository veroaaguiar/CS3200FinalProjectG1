package com.example.p2.users;

import com.example.p2.passports.Passport;
import com.example.p2.shippingAddresses.ShippingAddress;
import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;
import javax.persistence.*;

@Entity
@Table(name = "users_new")
public class User {
    @Id
    private Integer uId;
    private String firstName;
    private String lastName;
    private Timestamp dateOfBirth;
    private String password;
    private String email;
    private String username;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    @OneToOne()
    @JoinColumn(name = "passport_number")
    @JsonIgnore
    private Passport passportNumber;

    @OneToOne
    @JsonIgnore
    @JoinColumn(name = "a_id")
    private ShippingAddress aId;
    @OneToMany
    @JsonIgnore
    private List<ShippingAddress> addresses;



    @Transient
    public Integer getPassportId() {
        if (passportNumber == null) {
            return 0;
        }
        return passportNumber.getPassportNumber();
    }



    public Passport getPassportNumber() {
        return passportNumber;
    }

    public void setPassportNumber(Passport passportNumber) {
        this.passportNumber = passportNumber;
    }

    public Integer getuId() {
        return uId;
    }

    public void setuId(Integer uId) {
        this.uId = uId;
    }

    public Timestamp getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(Timestamp dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }

    public Integer getAddressId() {
        if(aId == null) {
            return 0;
        }
        return aId.getaId();
    }

    public ShippingAddress getaId() {
        return aId;
    }

    public void setaId() {
        this.aId = this.aId;
    }

    public List<ShippingAddress> getAddresses() {
        return addresses;
    }

    public void setAddresses(List<ShippingAddress> Addresses) {
        this.addresses = this.addresses;
    }


    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }


    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

}

