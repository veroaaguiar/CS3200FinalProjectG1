package com.example.p2.passports;
import com.example.p2.users.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;;


@RestController
@CrossOrigin(origins = "*")
public class PassportDAO {
    @Autowired
    PassportRepository passportRepository;

    @PostMapping("/api/passports")
    public Passport createPassport(@RequestBody Passport passport) {

        return passportRepository.save(passport);
    }

    @GetMapping("/api/passports")
    public List<Passport> findAllPassports() {
        return (List<Passport>) passportRepository.findAll();
    }
    @GetMapping("/api/passports/{passportNumber}")
    public Passport findPassportById(
            @PathVariable("passportNumber") Integer passportNumber) {
        return passportRepository.findById(passportNumber).get();
    }

    @PutMapping("/api/passports/{passportNumber}")
    public Passport updatePassport(
            @PathVariable("passportNumber") Integer passportNumber,
            @RequestBody Passport passportUpdates) {
        Passport passport = passportRepository.findById(passportNumber).get();
        passport.setPassportNumber(passportUpdates.getPassportNumber());
        passport.setExpiration(passportUpdates.getExpiration());
        return passportRepository.save(passport);
    }

    @DeleteMapping("/api/passports/{passportNumber}")
    public void deletePassport(
            @PathVariable("passportNumber") Integer passportNumber) {
        passportRepository.deleteById(passportNumber);
    }



}
