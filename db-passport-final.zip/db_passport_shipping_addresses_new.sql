-- MySQL dump 10.13  Distrib 8.0.26, for macos11 (x86_64)
--
-- Host: 127.0.0.1    Database: db_passport
-- ------------------------------------------------------
-- Server version	8.0.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `shipping_addresses_new`
--

DROP TABLE IF EXISTS `shipping_addresses_new`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shipping_addresses_new` (
  `a_id` int NOT NULL,
  `u_id` int NOT NULL,
  `address` varchar(45) NOT NULL,
  PRIMARY KEY (`a_id`),
  UNIQUE KEY `a_id_UNIQUE` (`a_id`),
  KEY `shipping_address_to_user_idx` (`u_id`),
  CONSTRAINT `shipping_address_to_user_new` FOREIGN KEY (`u_id`) REFERENCES `users_new` (`u_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shipping_addresses_new`
--

LOCK TABLES `shipping_addresses_new` WRITE;
/*!40000 ALTER TABLE `shipping_addresses_new` DISABLE KEYS */;
INSERT INTO `shipping_addresses_new` VALUES (1,1,'1 Avery Street, Boston, MA, USA'),(2,2,'2 San Roman, Caracas, Miranda, VE'),(3,3,'4 Main Street, Orlando, FL. USA'),(4,1,'3334 Islewood Avenue, Weston, Fl, USA'),(5,2,'33 Brookline Avenue, Brookline, MA, USA'),(6,4,'Quinta Quatro Cafetal, Caracas, DC, VE'),(7,5,'33 Huntington Avenue, Boston, MA, USA'),(8,6,'456 Biscayne Blvd, Aventura, FL, USA'),(9,7,'California Tower 3, Los Angeles, CA, USA'),(10,3,'18 Gran Via, Madrid, ESP'),(11,1,'291 Saint Botolph Street, Boston, MA ');
/*!40000 ALTER TABLE `shipping_addresses_new` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-12-15 13:50:58
