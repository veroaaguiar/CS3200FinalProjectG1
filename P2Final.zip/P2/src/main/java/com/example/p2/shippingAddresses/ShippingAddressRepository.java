package com.example.p2.shippingAddresses;

import org.springframework.data.repository.CrudRepository;

public interface ShippingAddressRepository extends
        CrudRepository<ShippingAddress, Integer> {

}
