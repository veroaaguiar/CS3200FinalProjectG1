package com.example.p2.users;
import com.example.p2.passports.PassportRepository;
import com.example.p2.users.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@CrossOrigin(origins = "*")
public class UserDAO {
    @Autowired
    UserRepository userRepository;
    @Autowired
    PassportRepository passportRepository;

    @PostMapping("/api/users")
    public User createUser(@RequestBody User user) {
        return userRepository.save(user);
    }

    @GetMapping("/api/users")
    public List<User> findAllUsers() {
        return (List<User>) userRepository.findAll();
    }

    @GetMapping("/api/users/{uId}")
    public User findUserById(
            @PathVariable("uId") Integer uId) {
        return userRepository.findById(uId).get();
    }
    @PutMapping("/api/users/{uId}")
    public User updateUser(
            @PathVariable("uId") Integer uId,
            @RequestBody User userUpdates) {
        User user = userRepository.findById(uId).get();
        user.setuId(userUpdates.getuId());
        user.setFirstName(userUpdates.getFirstName());
        user.setLastName(userUpdates.getLastName());
//        user.setDateOfBirth(userUpdates.getDateOfBirth());
        user.setPassword(userUpdates.getPassword());
        user.setEmail(userUpdates.getEmail());
        user.setPassportNumber(userUpdates.getPassportNumber());
//        user.setaId(userUpdates.getaId());
        return userRepository.save(user);
    }

    @DeleteMapping("/api/users/{uId}")
    public void deleteUser(
            @PathVariable("uId") Integer uId) {
        User user = findUserById(uId);
        passportRepository.deleteById(user.getPassportId());
        userRepository.deleteById(uId);
    }

}

